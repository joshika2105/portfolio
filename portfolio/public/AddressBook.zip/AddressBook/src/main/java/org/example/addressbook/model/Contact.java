package org.example.addressbook.model;

import java.util.concurrent.atomic.AtomicInteger;

public class Contact {
    private int id;
    private String name;
    private String email;
    private int age;
    private boolean isBusinessContact;

    public Contact(String name, String email, int age, boolean isBusinessContact){
        this.id = -1;
        this.name = name;
        setEmail(email);
        setAge(age);
        this.isBusinessContact = isBusinessContact;
    }

    //mit id zusaetzlich fuer DB
    public Contact(int id, String name, String email, int age, boolean isBusinessContact){
        this.id = id;
        this.name = name;
        setEmail(email);
        setAge(age);
        this.isBusinessContact = isBusinessContact;
    }

    public int getId() {
        return id;
    }
    //kann von DB jetzt kommen
    public void setId(int id) { this.id = id; }

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        if (!email.matches("^[\\w.-]+@[\\w.-]+\\.[a-zA-Z]{2,}$")){
            throw new IllegalArgumentException("Invalid email address: " + email);
        }
        this.email = email;
    }

    public int getAge() {
        return age;
    }
    public void setAge(int age) {
        if (age < 0){
            throw new IllegalArgumentException("Age cannot be negative: " + age);
        }
        this.age = age;
    }

    public boolean isBusinessContact() {
        return isBusinessContact;
    }
    public void setBusinessContact(boolean businessContact) {
        isBusinessContact = businessContact;
    }

    @Override
    public String toString(){
        return name;
    }
}
