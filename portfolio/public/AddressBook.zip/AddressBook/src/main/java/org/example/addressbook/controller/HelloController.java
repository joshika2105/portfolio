package org.example.addressbook.controller;

import javafx.collections.transformation.FilteredList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import org.example.addressbook.model.AddressBook;
import org.example.addressbook.model.Contact;

public class HelloController {
    @FXML
    private CheckBox cbIsBusinessContact;

    @FXML
    private Label lblAverageAge;

    @FXML
    private Label lblNumOfBusinessContacts;

    @FXML
    private Label lblNumOfContacts;

    @FXML
    private Label lblOldestContact;

    @FXML
    private Label lblTLDs;

    @FXML
    private TextField txtAge;

    @FXML
    private TextField txtID;

    @FXML
    private ListView<Contact> txtListView;

    @FXML
    private TextField searchField;

    @FXML
    private TextField txtMail;

    @FXML
    private TextField txtName;

    private final AddressBook addressBook = AddressBook.getInstance();
    private FilteredList<Contact> filteredList;

    @FXML
    public void initialize(){
        filteredList = new FilteredList<>(addressBook.getContacts(), p -> true);
        txtListView.setItems(filteredList);

        //Statistik-Bindings
        lblNumOfContacts.textProperty().bind(addressBook.totalContactsProperty().asString());
        lblNumOfBusinessContacts.textProperty().bind(addressBook.businessContactsProperty().asString());
        lblOldestContact.textProperty().bind(addressBook.oldestContactProperty());
        lblAverageAge.textProperty().bind(addressBook.averageAgeProperty().asString("%.2f"));
        lblTLDs.textProperty().bind(addressBook.uniqueTLDsProperty().asString());

        //Auswahl -> Felder fuellen
        txtListView.getSelectionModel().selectedItemProperty()
                .addListener((obs, oldVal, newVal) -> fillFields(newVal));
    }

    private void fillFields(Contact c){
        if (c == null){
            txtID.clear();
            txtName.clear();
            txtMail.clear();
            txtAge.clear();
            cbIsBusinessContact.setSelected(false);
            return;
        }

        txtID.setText(String.valueOf(c.getId()));
        txtName.setText(c.getName());
        txtMail.setText(c.getEmail());
        txtAge.setText(String.valueOf(c.getAge()));
        cbIsBusinessContact.setSelected(c.isBusinessContact());
    }

    private void showAlert(String message){
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Fehler");
        alert.setHeaderText("Ungültige Eingabe");
        alert.setContentText(message);
        alert.showAndWait();
    }

    @FXML
    void handleDeleteClicked() {
        Contact selected = txtListView.getSelectionModel().getSelectedItem();
        if (selected != null){
            addressBook.deleteContact(selected);
            fillFields(null);
        }
    }

    @FXML
    void handleNewClicked() {
        txtListView.getSelectionModel().clearSelection();
        txtID.setText("(auto)");
        txtName.clear();
        txtMail.clear();
        txtAge.clear();
        cbIsBusinessContact.setSelected(false);
    }

    @FXML
    void handleSaveClicked() {
        try{
            String name = txtName.getText();
            String email = txtMail.getText();
            int age = Integer.parseInt(txtAge.getText());
            boolean isBusiness = cbIsBusinessContact.isSelected();

            Contact selected = txtListView.getSelectionModel().getSelectedItem();
            if (selected == null){
                addressBook.addContact(name, email, age, isBusiness);
            } else {
                addressBook.updateContact(selected, name, email, age, isBusiness);
                txtListView.refresh();
            }
        } catch (NumberFormatException e) {
            showAlert("Age must be a valid number.");
        } catch (IllegalArgumentException e){
            showAlert(e.getMessage());
        }
    }

    @FXML
    void handleSearchClicked() {
        String query = searchField.getText();
        filteredList.setPredicate(contact -> {
            if (query == null || query.isBlank()){
                return true;
            }

            String lower = query.toLowerCase();
            return contact.getName().toLowerCase().contains(lower)
                    || contact.getEmail().toLowerCase().contains(lower);
        });
    }
}

