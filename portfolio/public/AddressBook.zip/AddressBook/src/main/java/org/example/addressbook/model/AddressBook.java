package org.example.addressbook.model;

import javafx.beans.property.*;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import org.example.addressbook.DatabaseManager;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Comparator;

public class AddressBook {
    private static AddressBook instance;

    private final ObservableList<Contact> contacts = FXCollections.observableArrayList();
    private final ObservableList<Contact> readOnlyContacts = FXCollections.unmodifiableObservableList(contacts);

    private final IntegerProperty totalContacts = new SimpleIntegerProperty(0);
    private final IntegerProperty businessContacts = new SimpleIntegerProperty(0);
    private final DoubleProperty averageAge = new SimpleDoubleProperty(0.0);
    private final StringProperty oldestContact = new SimpleStringProperty("None");
    private final IntegerProperty uniqueTLDs = new SimpleIntegerProperty(0);


    private AddressBook(){
        contacts.addListener((ListChangeListener<Contact>) c -> updateStatistics());
        loadFromDatabase();     //alle Kontakte aus der Datenbank laden beim Starten
    }

    public static AddressBook getInstance(){    //Lazy Initialization
        if (instance == null){
            instance = new AddressBook();
        }
        return instance;
    }

    public ObservableList<Contact> getContacts(){
        return readOnlyContacts;
    }

    //Laden aus der Datenbank
    private void loadFromDatabase() {
        String sql = "SELECT ID, NAME, EMAIL, AGE, IS_BUSINESS FROM CONTACT";
        try (Statement stmt = DatabaseManager.getConnection().createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                contacts.add(new Contact(
                        rs.getInt("ID"),
                        rs.getString("NAME"),
                        rs.getString("EMAIL"),
                        rs.getInt("AGE"),
                        rs.getBoolean("IS_BUSINESS")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //erweitert für DB
    public void addContact(String name, String email, int age, boolean isBusiness){
        String sql = "INSERT INTO CONTACT (NAME, EMAIL, AGE, IS_BUSINESS) VALUES (?, ?, ?, ?)";
        try(PreparedStatement ps = DatabaseManager.getConnection().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)){
            ps.setString(1, name);
            ps.setString(2, email);
            ps.setInt(3, age);
            ps.setBoolean(4, isBusiness);
            ps.executeUpdate();

            ResultSet keys = ps.getGeneratedKeys();
            if (keys.next()){
                Contact c = new Contact(keys.getInt(1), name, email, age, isBusiness);
                contacts.add(c);
            }

        } catch (SQLException e){
            e.printStackTrace();
        }
    }

    //erweitert für DB
    public void updateContact(Contact c, String name, String email, int age, boolean isBusiness){
        String sql = "UPDATE CONTACT SET NAME=?, EMAIL=?, AGE=?, IS_BUSINESS=? WHERE ID=?";

        try (PreparedStatement ps = DatabaseManager.getConnection().prepareStatement(sql)){
            ps.setString(1, name);
            ps.setString(2, email);
            ps.setInt(3, age);
            ps.setBoolean(4, isBusiness);
            ps.setInt(5, c.getId());
            ps.executeUpdate();

            // lokales Objekt auch aktualisieren
            c.setName(name);
            c.setEmail(email);
            c.setAge(age);
            c.setBusinessContact(isBusiness);
            updateStatistics();

        } catch (SQLException e){
            e.printStackTrace();
        }
    }

    //erweitert für DB
    public void deleteContact(Contact c){
        String sql = "DELETE FROM CONTACT WHERE ID=?";
        try(PreparedStatement ps = DatabaseManager.getConnection().prepareStatement(sql)){
            ps.setInt(1, c.getId());
            ps.executeUpdate();

            contacts.remove(c);

        } catch (SQLException e){
            e.printStackTrace();
        }
    }

    private void updateStatistics(){
        totalContacts.set(contacts.size());

        businessContacts.set((int)contacts.stream()
                .filter(Contact::isBusinessContact)
                .count());

        averageAge.set(contacts.stream()
                .mapToInt(Contact::getAge)
                .average()
                .orElse(0.0));

        oldestContact.set(contacts.stream()
                .max(Comparator.comparingInt(Contact::getAge))
                .map(Contact::getName)
                .orElse("None"));

        uniqueTLDs.set((int)contacts.stream()
                .map(c -> {
                    String email = c.getEmail();
                    return email.substring(email.lastIndexOf('.'));
                })
                .distinct()
                .count());
    }

    public IntegerProperty totalContactsProperty() { return totalContacts; }
    public IntegerProperty businessContactsProperty() { return businessContacts; }
    public DoubleProperty averageAgeProperty() { return averageAge; }
    public StringProperty oldestContactProperty() { return oldestContact; }
    public IntegerProperty uniqueTLDsProperty() { return uniqueTLDs; }
}
