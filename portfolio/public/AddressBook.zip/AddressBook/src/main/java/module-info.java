module org.example.addressbook {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens org.example.addressbook to javafx.fxml;
    exports org.example.addressbook;
    exports org.example.addressbook.controller;
    opens org.example.addressbook.controller to javafx.fxml;
    exports org.example.addressbook.model;
    opens org.example.addressbook.model to javafx.fxml;
}